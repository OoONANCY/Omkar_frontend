function Research() {
  return (
    <section className="research">
      <h2>Research on Brain Tumor Segmentation</h2>
      <div className="research-content">
        <div className="research-text">
          <p>Explore cutting-edge research on brain tumor segmentation using AI-powered models like UNet3D and Swin UNETR.</p>
          <button className="primary-btn">Read More</button>
        </div>
        
      </div>
    </section>
  );
}

export default Research;
