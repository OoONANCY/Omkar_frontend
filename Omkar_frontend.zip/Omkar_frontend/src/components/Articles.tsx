"use client"

import type React from "react"
import { useState, useEffect } from "react"

const VQAInterface: React.FC = () => {
  const [image, setImage] = useState<File | null>(null)
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [question, setQuestion] = useState<string>("")
  const [answer, setAnswer] = useState<string>("")
  const [error, setError] = useState<string>("")
  const [isLoading, setIsLoading] = useState<boolean>(false)

  useEffect(() => {
    if (image) {
      const url = URL.createObjectURL(image)
      setImageUrl(url)
      return () => URL.revokeObjectURL(url)
    }
  }, [image])

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError("")
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0]
      // Add image validation
      if (!file.type.startsWith('image/')) {
        setError("Please upload an image file")
        return
      }
      setImage(file)
    }
  }

  const handleQuestionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError("")
    setQuestion(event.target.value)
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()
    setError("")
    
    if (!image || !question) {
      setError("Please provide both an image and a question")
      return
    }

    setIsLoading(true)
    try {
      const formData = new FormData()
      formData.append("file", image)  // Using "file" to match API expectation
      formData.append("question", question)

      const response = await fetch("http://127.0.0.1:5000/predict/", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Failed to get prediction')
      }

      const data = await response.json()
      if (data.error) {
        throw new Error(data.error)
      }
      
      setAnswer(data.answer)
    } catch (error) {
      setError(error instanceof Error ? error.message : "An error occurred while processing your request")
      setAnswer("")
    } finally {
      setIsLoading(false)
    }
  }


  return (
    <div className="vqa-container">
      <div className="hero-section">
        <h1>NeuroVision</h1>
        <p>Chat with our NeuroVision Bot</p>
      </div>
      <div className="content-card">
        <form onSubmit={handleSubmit}>
          <div className="upload-section">
            <label htmlFor="image-input" className="upload-label">
              <div className="upload-area">
                {imageUrl ? (
                  <img src={imageUrl || "/placeholder.svg"} alt="Uploaded scan" className="preview-image" />
                ) : (
                  <div className="upload-placeholder">
                    <span>Upload Brain Scan Image</span>
                    <span className="upload-subtitle">Click or drag and drop</span>
                  </div>
                )}
              </div>
              <input
                type="file"
                id="image-input"
                accept="image/*"
                onChange={handleImageUpload}
                className="file-input"
              />
            </label>
          </div>
          <div className="question-section">
            <input
              type="text"
              value={question}
              onChange={handleQuestionChange}
              placeholder="Ask a question about the brain scan..."
              className="question-input"
            />
            <button type="submit" className="submit-button" disabled={!image || !question || isLoading}>
              {isLoading ? "Analyzing..." : "Get Answer"}
            </button>
          </div>
        </form>
        {answer && (
          <div className="answer-section">
            <h2>Analysis Result</h2>
            <p>{answer}</p>
          </div>
        )}
      </div>
      <style jsx>{`
        .vqa-container {
          min-height: 100vh;
          background-color: #000;
          color: white;
          font-family: Arial, sans-serif;
        }

        .hero-section {
          text-align: center;
          padding: 80px 20px;
          position: relative;
          overflow: hidden;
        }

        .hero-section::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 600px;
          height: 600px;
          background: radial-gradient(circle, rgba(255,255,0,0.1) 0%, rgba(0,255,255,0.1) 50%, rgba(255,0,255,0.1) 100%);
          filter: blur(100px);
          z-index: 1;
        }

        .hero-section h1 {
          font-size: 48px;
          margin: 0;
          position: relative;
          z-index: 2;
        }

        .hero-section p {
          font-size: 18px;
          color: #ccc;
          margin-top: 20px;
          position: relative;
          z-index: 2;
        }

        .content-card {
          background-color: rgba(255, 255, 255, 0.05);
          border-radius: 12px;
          padding: 30px;
          max-width: 800px;
          margin: 0 auto 60px;
          backdrop-filter: blur(10px);
        }

        .upload-section {
          margin-bottom: 30px;
        }

        .upload-label {
          display: block;
          cursor: pointer;
        }

        .upload-area {
          border: 2px dashed rgba(255, 255, 255, 0.2);
          border-radius: 8px;
          padding: 40px;
          text-align: center;
          transition: all 0.3s ease;
        }

        .upload-area:hover {
          border-color: rgba(255, 255, 255, 0.4);
        }

        .upload-placeholder {
          display: flex;
          flex-direction: column;
          gap: 10px;
          color: #ccc;
        }

        .upload-subtitle {
          font-size: 14px;
          opacity: 0.7;
        }

        .file-input {
          display: none;
        }

        .preview-image {
          max-width: 100%;
          max-height: 400px;
          border-radius: 8px;
        }

        .question-section {
          display: flex;
          gap: 15px;
          margin-bottom: 30px;
        }

        .question-input {
          flex: 1;
          padding: 12px 20px;
          border: none;
          border-radius: 6px;
          background-color: rgba(255, 255, 255, 0.1);
          color: white;
          font-size: 16px;
        }

        .question-input::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }

        .submit-button {
          padding: 12px 30px;
          background-color: white;
          color: black;
          border: none;
          border-radius: 6px;
          font-size: 16px;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .submit-button:hover:not(:disabled) {
          transform: translateY(-2px);
        }

        .submit-button:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .answer-section {
          margin-top: 30px;
          padding-top: 30px;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .answer-section h2 {
          font-size: 24px;
          margin-bottom: 15px;
        }

        .answer-section p {
          color: #ccc;
          line-height: 1.6;
        }

        @media (max-width: 768px) {
          .content-card {
            margin: 20px;
          }

          .question-section {
            flex-direction: column;
          }

          .submit-button {
            width: 100%;
          }
        }
      `}</style>
    </div>
  )
}

export default VQAInterface

 
