function Products() {
  return (
    <section className="products">
      <h2 className="section-heading">Our Products</h2> {/* Added section heading */}
      <div className="products-grid">
        {/* Chatbot Product Card */}
        <div className="product-card">
          <h3>
            <span className="icon">💬</span>
            AI-powered Chatbot
          </h3>
          <p>Engage with patients and medical professionals in real-time through a smart chatbot interface.</p>
        </div>
        
        {/* Brain Tumor Segmentation Product Card */}
        <div className="product-card">
          <h3>
            <span className="icon">🧠</span>
            Brain Tumor Segmentation
          </h3>
          <p>Accurately detect and segment brain tumors in medical images with AI-driven precision.</p>
        </div>
      </div>
    </section>
  );
}

export default Products;
